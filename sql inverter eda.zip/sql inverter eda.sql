use project_253;
CREATE TABLE inverter (
Date_Time TEXT,
Power_of_inverter1_in_unit1 DOUBLE,
Power_of_inverter2_in_unit1 DOUBLE,
Power_of_inverter1_in_unit2 DOUBLE,
Power_of_inverter2_in_unit2 DOUBLE
);
LOAD DATA INFILE "C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\inverter dataset csv.csv"
into table inverter
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 rows;

#mean.......................... 


SELECT AVG(Power_of_inverter1_in_unit1) AS Mean1_Value FROM inverter;
SELECT AVG(Power_of_inverter2_in_unit1) AS Mean2_Value FROM inverter;
SELECT AVG(Power_of_inverter1_in_unit2) AS Mean3_Value FROM inverter;
SELECT AVG(Power_of_inverter2_in_unit2) AS Mean4_Value FROM inverter;

---------------------------

#Median..................... 


WITH Ranked AS (
SELECT Power_of_inverter1_in_unit1, ROW_NUMBER() OVER (ORDER BY Power_of_inverter1_in_unit1) AS row_num,
COUNT(*) OVER () AS total_rows
FROM inverter
)
SELECT AVG(Power_of_inverter1_in_unit1) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));

WITH Ranked AS (
SELECT Power_of_inverter2_in_unit1, ROW_NUMBER() OVER (ORDER BY Power_of_inverter2_in_unit1) AS row_num,
COUNT(*) OVER () AS total_rows
FROM inverter
)
SELECT AVG(Power_of_inverter2_in_unit1) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));

WITH Ranked AS (
SELECT Power_of_inverter1_in_unit2, ROW_NUMBER() OVER (ORDER BY Power_of_inverter1_in_unit2) AS row_num,
COUNT(*) OVER () AS total_rows
FROM inverter
)
SELECT AVG(Power_of_inverter1_in_unit2) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));


WITH Ranked AS (
SELECT Power_of_inverter2_in_unit2, ROW_NUMBER() OVER (ORDER BY Power_of_inverter2_in_unit2) AS row_num,
COUNT(*) OVER () AS total_rows
FROM inverter
)
SELECT AVG(Power_of_inverter2_in_unit2) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));

---------------------------

#mode......................... 


SELECT Power_of_inverter1_in_unit1 as mode_value
FROM inverter
GROUP BY Power_of_inverter1_in_unit1
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT Power_of_inverter2_in_unit1 as mode_value
FROM inverter
GROUP BY Power_of_inverter2_in_unit1
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT Power_of_inverter1_in_unit2 as mode_value
FROM inverter
GROUP BY Power_of_inverter1_in_unit2
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT Power_of_inverter2_in_unit2 as mode_value
FROM inverter
GROUP BY Power_of_inverter2_in_unit2
ORDER BY COUNT(*) DESC
LIMIT 1;

---------------------------

#variance....................... 


SELECT VARIANCE(Power_of_inverter1_in_unit1) AS Variance_Value FROM inverter;
SELECT VARIANCE(Power_of_inverter2_in_unit1) AS Variance_Value2 FROM inverter;
SELECT VARIANCE(Power_of_inverter1_in_unit2) AS Variance_Value3 FROM inverter;
SELECT VARIANCE(Power_of_inverter2_in_unit2) AS Variance_Value4 FROM inverter;
---------------------------



#standared deviation...................... 


SELECT STDDEV(Power_of_inverter1_in_unit1) AS Standard_Deviation1 FROM inverter;
SELECT STDDEV(Power_of_inverter2_in_unit1) AS Standard_Deviation2 FROM inverter;
SELECT STDDEV(Power_of_inverter1_in_unit2) AS Standard_Deviation3 FROM inverter;
SELECT STDDEV(Power_of_inverter2_in_unit2) AS Standard_Deviation4 FROM inverter;
---------------------------


#range................. 


SELECT MAX(Power_of_inverter1_in_unit1) - MIN(Power_of_inverter1_in_unit1) AS Range_Value1
FROM inverter;
SELECT MAX(Power_of_inverter2_in_unit1) - MIN(Power_of_inverter2_in_unit1) AS Range_Value2
FROM inverter;
SELECT MAX(Power_of_inverter1_in_unit2) - MIN(Power_of_inverter1_in_unit2) AS Range_Value3
FROM inverter;
SELECT MAX(Power_of_inverter2_in_unit2) - MIN(Power_of_inverter2_in_unit2) AS Range_Value4
FROM inverter;
---------------------------

#skewness..................... 


SELECT 
(COUNT(Power_of_inverter1_in_unit1) / ((COUNT(Power_of_inverter1_in_unit1) - 1) * (COUNT(Power_of_inverter1_in_unit1) - 2))) *
SUM(POWER((Power_of_inverter1_in_unit1 - (SELECT AVG(Power_of_inverter1_in_unit1) FROM wmsreport)) /
(SELECT STDDEV(Power_of_inverter1_in_unit1) FROM wmsreport), 3)) AS Skewness1
FROM inverter;

SELECT 
(COUNT(Power_of_inverter2_in_unit1) / ((COUNT(Power_of_inverter2_in_unit1) - 1) * (COUNT(Power_of_inverter2_in_unit1) - 2))) *
SUM(POWER((Power_of_inverter2_in_unit1 - (SELECT AVG(Power_of_inverter2_in_unit1) FROM wmsreport)) /
(SELECT STDDEV(Power_of_inverter2_in_unit1) FROM wmsreport), 3)) AS Skewness2
FROM inverter;

SELECT 
(COUNT(Power_of_inverter1_in_unit2) / ((COUNT(Power_of_inverter1_in_unit2) - 1) * (COUNT(Power_of_inverter1_in_unit2) - 2))) *
SUM(POWER((Power_of_inverter1_in_unit2 - (SELECT AVG(Power_of_inverter1_in_unit2) FROM wmsreport)) /
(SELECT STDDEV(Power_of_inverter1_in_unit2) FROM wmsreport), 3)) AS Skewness3
FROM inverter;

SELECT 
(COUNT(Power_of_inverter2_in_unit2) / ((COUNT(Power_of_inverter2_in_unit2) - 1) * (COUNT(Power_of_inverter2_in_unit2) - 2))) *
SUM(POWER((Power_of_inverter2_in_unit2 - (SELECT AVG(Power_of_inverter2_in_unit2) FROM wmsreport)) /
(SELECT STDDEV(Power_of_inverter2_in_unit2) FROM wmsreport), 3)) AS Skewness4
FROM inverter;
---------------------------

#kurtosis.......................... 


SELECT 
((COUNT(Power_of_inverter1_in_unit1) * (COUNT(Power_of_inverter1_in_unit1) + 1)) / 
((COUNT(Power_of_inverter1_in_unit1) - 1) * (COUNT(Power_of_inverter1_in_unit1) - 2) * (COUNT(Power_of_inverter1_in_unit1) - 3))) *
SUM(POWER((Power_of_inverter1_in_unit1 - (SELECT AVG(Power_of_inverter1_in_unit1) FROM inverter)) /
(SELECT STDDEV(Power_of_inverter1_in_unit1) FROM inverter), 4)) 
- (3 * POWER(COUNT(Power_of_inverter1_in_unit1) - 1, 2) / 
((COUNT(Power_of_inverter1_in_unit1) - 2) * (COUNT(Power_of_inverter1_in_unit1) - 3))) AS Kurtosis1
FROM inverter;

SELECT 
((COUNT(Power_of_inverter2_in_unit1) * (COUNT(Power_of_inverter2_in_unit1) + 1)) / 
((COUNT(Power_of_inverter2_in_unit1) - 1) * (COUNT(Power_of_inverter2_in_unit1) - 2) * (COUNT(Power_of_inverter2_in_unit1) - 3))) *
SUM(POWER((Power_of_inverter2_in_unit1 - (SELECT AVG(Power_of_inverter2_in_unit1) FROM inverter)) /
(SELECT STDDEV(Power_of_inverter2_in_unit1) FROM inverter), 4)) 
- (3 * POWER(COUNT(Power_of_inverter2_in_unit1) - 1, 2) / 
    ((COUNT(Power_of_inverter2_in_unit1) - 2) * (COUNT(Power_of_inverter2_in_unit1) - 3))) AS Kurtosis2
FROM inverter;

SELECT 
((COUNT(Power_of_inverter1_in_unit2) * (COUNT(Power_of_inverter1_in_unit2) + 1)) / 
((COUNT(Power_of_inverter1_in_unit2) - 1) * (COUNT(Power_of_inverter1_in_unit2) - 2) * (COUNT(Power_of_inverter1_in_unit2) - 3))) *
SUM(POWER((Power_of_inverter1_in_unit2 - (SELECT AVG(Power_of_inverter1_in_unit2) FROM inverter)) /
(SELECT STDDEV(Power_of_inverter1_in_unit2) FROM inverter), 4)) 
- (3 * POWER(COUNT(Power_of_inverter1_in_unit2) - 1, 2) / 
((COUNT(Power_of_inverter1_in_unit2) - 2) * (COUNT(Power_of_inverter1_in_unit2) - 3))) AS Kurtosis3
FROM inverter;

SELECT 
((COUNT(Power_of_inverter2_in_unit2) * (COUNT(Power_of_inverter2_in_unit2) + 1)) / 
((COUNT(Power_of_inverter2_in_unit2) - 1) * (COUNT(Power_of_inverter2_in_unit2) - 2) * (COUNT(Power_of_inverter2_in_unit2) - 3))) *
SUM(POWER((Power_of_inverter2_in_unit2 - (SELECT AVG(Power_of_inverter2_in_unit2) FROM inverter)) /
(SELECT STDDEV(Power_of_inverter2_in_unit2) FROM inverter), 4)) 
- (3 * POWER(COUNT(Power_of_inverter2_in_unit2) - 1, 2) / 
((COUNT(Power_of_inverter2_in_unit2) - 2) * (COUNT(Power_of_inverter2_in_unit2) - 3))) AS Kurtosis3
FROM inverter;