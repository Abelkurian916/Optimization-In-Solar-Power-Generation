create database project_253;
use project_253;
CREATE TABLE wmsreport (
    Date_Time TEXT,
    GII DOUBLE,
    MODULE_TEMP_1 DOUBLE,
    RAIN DOUBLE,
    AMBIENT_TEMPERATURE DOUBLE
);
LOAD DATA INFILE "C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\WMS Report csv.csv"
into table wmsreport
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 rows;


#mean........................

SELECT AVG(GII) AS Mean_Value FROM wmsreport;
SELECT AVG(MODULE_TEMP_1) AS Mean_Value FROM wmsreport;
SELECT AVG(RAIN) AS Mean_Value FROM wmsreport;
SELECT AVG(AMBIENT_TEMPERATURE) AS Mean_Value FROM wmsreport;

#Median...................... 


WITH Ranked AS (
SELECT GII, ROW_NUMBER() OVER (ORDER BY GII) AS row_num,
COUNT(*) OVER () AS total_rows
FROM wmsreport
)
SELECT AVG(GII) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));

WITH Ranked AS (
SELECT MODULE_TEMP_1, ROW_NUMBER() OVER (ORDER BY MODULE_TEMP_1) AS row_num,
COUNT(*) OVER () AS total_rows
FROM wmsreport
)
SELECT AVG(MODULE_TEMP_1) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));

WITH Ranked AS (
SELECT RAIN, ROW_NUMBER() OVER (ORDER BY RAIN) AS row_num,
COUNT(*) OVER () AS total_rows
FROM wmsreport
)
SELECT AVG(RAIN) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));


WITH Ranked AS (
SELECT AMBIENT_TEMPERATURE, ROW_NUMBER() OVER (ORDER BY AMBIENT_TEMPERATURE) AS row_num,
COUNT(*) OVER () AS total_rows
FROM wmsreport
)
SELECT AVG(AMBIENT_TEMPERATURE) AS Median_Value
FROM Ranked
WHERE row_num IN (FLOOR((total_rows + 1) / 2), CEIL((total_rows + 1) / 2));

---------------------------

#mode......................... 


SELECT GII as mode_value
FROM wmsreport
GROUP BY GII
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT MODULE_TEMP_1 as mode_value
FROM wmsreport
GROUP BY MODULE_TEMP_1
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT RAIN as mode_value
FROM wmsreport
GROUP BY RAIN
ORDER BY COUNT(*) DESC
LIMIT 1;

SELECT AMBIENT_TEMPERATURE as mode_value
FROM wmsreport
GROUP BY AMBIENT_TEMPERATURE
ORDER BY COUNT(*) DESC
LIMIT 1;


#variance...................... 


SELECT VARIANCE(GII) AS Variance_Value FROM wmsreport;
SELECT VARIANCE(MODULE_TEMP_1) AS Variance_Value2 FROM wmsreport;
SELECT VARIANCE(RAIN) AS Variance_Value3 FROM wmsreport;
SELECT VARIANCE(AMBIENT_TEMPERATURE) AS Variance_Value4 FROM wmsreport;

#standared deviation........................ 


SELECT STDDEV(GII) AS Standard_Deviation1 FROM wmsreport;
SELECT STDDEV(MODULE_TEMP_1) AS Standard_Deviation2 FROM wmsreport;
SELECT STDDEV(RAIN) AS Standard_Deviation3 FROM wmsreport;
SELECT STDDEV(AMBIENT_TEMPERATURE) AS Standard_Deviation4 FROM wmsreport;

#range........................ 


SELECT MAX(GII) - MIN(GII) AS Range_Value1
FROM wmsreport;
SELECT MAX(MODULE_TEMP_1) - MIN(MODULE_TEMP_1) AS Range_Value2
FROM wmsreport;
SELECT MAX(RAIN) - MIN(RAIN) AS Range_Value3
FROM wmsreport;
SELECT MAX(AMBIENT_TEMPERATURE) - MIN(AMBIENT_TEMPERATURE) AS Range_Value4
FROM wmsreport;

#skewness........................... 


SELECT 
    (COUNT(GII) / ((COUNT(GII) - 1) * (COUNT(GII) - 2))) *
    SUM(POWER((GII - (SELECT AVG(GII) FROM wmsreport)) /
    (SELECT STDDEV(GII) FROM wmsreport), 3)) AS Skewness1
FROM wmsreport;

SELECT 
    (COUNT(MODULE_TEMP_1) / ((COUNT(MODULE_TEMP_1) - 1) * (COUNT(MODULE_TEMP_1) - 2))) *
    SUM(POWER((MODULE_TEMP_1 - (SELECT AVG(MODULE_TEMP_1) FROM wmsreport)) /
    (SELECT STDDEV(MODULE_TEMP_1) FROM wmsreport), 3)) AS Skewness2
FROM wmsreport;

SELECT 
    (COUNT(RAIN) / ((COUNT(RAIN) - 1) * (COUNT(RAIN) - 2))) *
    SUM(POWER((RAIN - (SELECT AVG(RAIN) FROM wmsreport)) /
    (SELECT STDDEV(RAIN) FROM wmsreport), 3)) AS Skewness3
FROM wmsreport;

SELECT 
    (COUNT(AMBIENT_TEMPERATURE) / ((COUNT(AMBIENT_TEMPERATURE) - 1) * (COUNT(AMBIENT_TEMPERATURE) - 2))) *
    SUM(POWER((AMBIENT_TEMPERATURE - (SELECT AVG(AMBIENT_TEMPERATURE) FROM wmsreport)) /
    (SELECT STDDEV(AMBIENT_TEMPERATURE) FROM wmsreport), 3)) AS Skewness4
FROM wmsreport;

#kurtosis........................... 


SELECT 
    ((COUNT(GII) * (COUNT(GII) + 1)) / 
    ((COUNT(GII) - 1) * (COUNT(GII) - 2) * (COUNT(GII) - 3))) *
    SUM(POWER((GII - (SELECT AVG(GII) FROM wmsreport)) /
    (SELECT STDDEV(GII) FROM wmsreport), 4)) 
    - (3 * POWER(COUNT(GII) - 1, 2) / 
    ((COUNT(GII) - 2) * (COUNT(GII) - 3))) AS Kurtosis1
FROM wmsreport;

SELECT 
    ((COUNT(MODULE_TEMP_1) * (COUNT(MODULE_TEMP_1) + 1)) / 
    ((COUNT(MODULE_TEMP_1) - 1) * (COUNT(MODULE_TEMP_1) - 2) * (COUNT(MODULE_TEMP_1) - 3))) *
    SUM(POWER((MODULE_TEMP_1 - (SELECT AVG(MODULE_TEMP_1) FROM wmsreport)) /
    (SELECT STDDEV(MODULE_TEMP_1) FROM wmsreport), 4)) 
    - (3 * POWER(COUNT(MODULE_TEMP_1) - 1, 2) / 
    ((COUNT(MODULE_TEMP_1) - 2) * (COUNT(MODULE_TEMP_1) - 3))) AS Kurtosis2
FROM wmsreport;

SELECT 
    ((COUNT(RAIN) * (COUNT(RAIN) + 1)) / 
    ((COUNT(RAIN) - 1) * (COUNT(RAIN) - 2) * (COUNT(RAIN) - 3))) *
    SUM(POWER((RAIN - (SELECT AVG(RAIN) FROM wmsreport)) /
    (SELECT STDDEV(RAIN) FROM wmsreport), 4)) 
    - (3 * POWER(COUNT(RAIN) - 1, 2) / 
    ((COUNT(RAIN) - 2) * (COUNT(RAIN) - 3))) AS Kurtosis3
FROM wmsreport;

SELECT 
    ((COUNT(AMBIENT_TEMPERATURE) * (COUNT(AMBIENT_TEMPERATURE) + 1)) / 
    ((COUNT(AMBIENT_TEMPERATURE) - 1) * (COUNT(AMBIENT_TEMPERATURE) - 2) * (COUNT(AMBIENT_TEMPERATURE) - 3))) *
    SUM(POWER((AMBIENT_TEMPERATURE - (SELECT AVG(AMBIENT_TEMPERATURE) FROM wmsreport)) /
    (SELECT STDDEV(AMBIENT_TEMPERATURE) FROM wmsreport), 4)) 
    - (3 * POWER(COUNT(AMBIENT_TEMPERATURE) - 1, 2) / 
    ((COUNT(AMBIENT_TEMPERATURE) - 2) * (COUNT(AMBIENT_TEMPERATURE) - 3))) AS Kurtosis3
FROM wmsreport;





